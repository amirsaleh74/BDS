# BDS LOGIXX Dashboard

Automated File Management & Monitoring System

## ✨ New Features

- ✅ **Password Protection** - Secure your dashboard with a password
- ✅ **Live Updates** - Stats update in real-time every 2 seconds
- ✅ **Fixed CSV Export** - Now works properly using POST method
- ✅ **Enlarged Input Fields** - Much bigger and easier to use
- ✅ **Session Management** - Stay logged in for 24 hours

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Set Environment Variables
Copy `.env.example` to `.env` and update:
```bash
DASHBOARD_PASSWORD=YourSecurePassword123
SESSION_SECRET=your-random-secret-here
```

### 3. Run Locally
```bash
npm start
```
Visit: http://localhost:3000

## 📦 Deploy to Railway

### 1. Push to GitHub
```bash
git add .
git commit -m "feat: Add password auth, live updates, fix CSV export"
git push origin main
```

### 2. Add Environment Variables in Railway
Go to your Railway project → Variables tab → Add:
- `DASHBOARD_PASSWORD` = Your secure password
- `SESSION_SECRET` = Random 32+ character string
- `NODE_ENV` = production

### 3. Railway Auto-Deploys
Railway will automatically detect changes and deploy!

## 🔐 Security

- **Password Protected**: Only authorized users can access
- **Session-Based Auth**: Secure session management with cookies
- **Environment Variables**: Sensitive data stored in env vars
- **HTTPS**: Railway provides SSL automatically

## 🎯 Features

### Dashboard
- Real-time stats (updates every 2 seconds)
- Total files tracked
- Files assigned today
- Watchlist monitoring
- Total activity logs

### Monitors
- **Shark Tank Monitor**: Manual scans and auto-monitoring
- **Watchlist Monitor**: Track specific App IDs, ALV numbers, phone numbers

### Quick Scraper
- Scrape 1-100 pages
- Export to CSV (now works!)
- Bulk assignment (coming soon)
- VoIP integration (coming soon)

## 🛠️ Tech Stack

- **Backend**: Node.js + Express
- **Frontend**: Vanilla JS (no framework bloat)
- **Realtime**: Server-Sent Events (SSE)
- **Deployment**: Railway.app
- **Database**: Supabase (optional)

## 📝 API Endpoints

### Public
- `GET /` - Dashboard home
- `POST /api/login` - Login with password

### Protected (requires auth)
- `GET /api/live-updates` - SSE stream for real-time updates
- `POST /api/export-csv` - Export data to CSV
- `POST /api/watchlist/add` - Add to watchlist
- `POST /api/scan/manual` - Run manual scan
- `POST /api/scraper/quick` - Quick scraper
- `POST /api/logout` - Logout

## 🐛 Troubleshooting

### CSV Export Not Working?
- ✅ Fixed! Now uses POST method instead of GET

### Input Box Too Small?
- ✅ Fixed! Inputs are now min 400px wide with 18px font

### Numbers Not Updating Live?
- ✅ Fixed! Uses Server-Sent Events for real-time updates

### Can't Access Dashboard?
- Make sure `DASHBOARD_PASSWORD` is set in Railway Variables
- Default password: `admin123` (change this!)

## 📄 License

MIT
