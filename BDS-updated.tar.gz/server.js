const express = require('express');
const session = require('express-session');
const path = require('path');
const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Session configuration for password protection
app.use(session({
  secret: process.env.SESSION_SECRET || 'change-this-to-random-string-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: process.env.NODE_ENV === 'production',
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Dashboard password from environment variable
const DASHBOARD_PASSWORD = process.env.DASHBOARD_PASSWORD || 'admin123';

// Global state for live updates (replace with your actual data source)
global.dashboardStats = {
  totalFiles: 0,
  filesAssigned: 0,
  watchlistCount: 0,
  totalActivity: 0
};

// Authentication middleware
function requireAuth(req, res, next) {
  if (req.session.authenticated) {
    return next();
  }
  res.status(401).json({ error: 'Unauthorized - Please login first' });
}

// Public routes (no auth required)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Login endpoint
app.post('/api/login', (req, res) => {
  const { password } = req.body;
  
  if (password === DASHBOARD_PASSWORD) {
    req.session.authenticated = true;
    res.json({ success: true, message: 'Login successful' });
  } else {
    res.status(401).json({ error: 'Invalid password' });
  }
});

// Logout endpoint
app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// Check authentication status
app.get('/api/auth-check', (req, res) => {
  res.json({ authenticated: !!req.session.authenticated });
});

// Protected routes (require authentication)
app.use('/api', requireAuth);

// Server-Sent Events for live updates
app.get('/api/live-updates', requireAuth, (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no'); // Disable nginx buffering
  
  // Send initial data
  res.write(`data: ${JSON.stringify(global.dashboardStats)}\n\n`);
  
  // Send updates every 2 seconds
  const interval = setInterval(() => {
    res.write(`data: ${JSON.stringify(global.dashboardStats)}\n\n`);
  }, 2000);
  
  // Clean up on client disconnect
  req.on('close', () => {
    clearInterval(interval);
  });
});

// CSV Export endpoint (FIXED - now uses POST)
app.post('/api/export-csv', requireAuth, async (req, res) => {
  try {
    const { data } = req.body;
    
    if (!data || !Array.isArray(data)) {
      return res.status(400).json({ error: 'Invalid data format' });
    }
    
    // Generate CSV
    const headers = Object.keys(data[0] || {}).join(',');
    const rows = data.map(row => 
      Object.values(row).map(val => `"${val}"`).join(',')
    ).join('\n');
    
    const csv = `${headers}\n${rows}`;
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=logixx-export.csv');
    res.send(csv);
  } catch (error) {
    console.error('CSV Export error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Add to watchlist
app.post('/api/watchlist/add', requireAuth, async (req, res) => {
  try {
    const { identifier } = req.body;
    
    // Your watchlist logic here (e.g., save to database)
    global.dashboardStats.watchlistCount++;
    
    res.json({ success: true, message: 'Added to watchlist' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Run manual scan
app.post('/api/scan/manual', requireAuth, async (req, res) => {
  try {
    // Your scan logic here
    res.json({ success: true, message: 'Scan started' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Quick scraper
app.post('/api/scraper/quick', requireAuth, async (req, res) => {
  try {
    const { pages } = req.body;
    
    // Your scraper logic here
    res.json({ success: true, message: `Scraping ${pages} pages` });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📊 Dashboard: http://localhost:${PORT}`);
  console.log(`🔐 Password protection: ${DASHBOARD_PASSWORD !== 'admin123' ? 'ENABLED' : 'USING DEFAULT PASSWORD'}`);
});
